from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse

def api_root(request):
    return JsonResponse({
        'message': 'College ERP API is running!',
        'endpoints': {
            'admin': '/admin/',
            'api_docs': 'Coming soon...',
            'admissions': '/api/admissions/',
            'fees': '/api/fees/',
            'hostel': '/api/hostel/',
            'library': '/api/library/',
            'dashboard': '/api/core/dashboard/metrics/'
        }
    })

urlpatterns = [
    path('', api_root, name='api-root'),
    path('admin/', admin.site.urls),
    path('api/admissions/', include('admissions.urls')),
    path('api/fees/', include('fees.urls')),
    path('api/hostel/', include('hostel.urls')),
    path('api/library/', include('library.urls')),
    path('api/core/', include('core.urls')),
]