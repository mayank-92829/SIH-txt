from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/admissions/', include('admissions.urls')),
    path('api/fees/', include('fees.urls')),
    path('api/hostel/', include('hostel.urls')),
    path('api/library/', include('library.urls')),
    path('api/core/', include('core.urls')),
]