from django.db import models
from admissions.models import Student

class Book(models.Model):
    BOOK_STATUS = (
        ('available', 'Available'),
        ('borrowed', 'Borrowed'),
        ('reserved', 'Reserved'),
        ('maintenance', 'Under Maintenance'),
    )
    
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    isbn = models.CharField(max_length=20, unique=True)
    publisher = models.CharField(max_length=100, blank=True)
    publication_year = models.IntegerField(blank=True, null=True)
    category = models.CharField(max_length=50, blank=True)
    total_copies = models.IntegerField(default=1)
    available_copies = models.IntegerField(default=1)
    status = models.CharField(max_length=15, choices=BOOK_STATUS, default='available')
    
    def __str__(self):
        return f"{self.title} by {self.author}"

class BookTransaction(models.Model):
    TRANSACTION_TYPES = (
        ('issue', 'Issue'),
        ('return', 'Return'),
        ('renew', 'Renew'),
    )
    
    TRANSACTION_STATUS = (
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('overdue', 'Overdue'),
    )
    
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    issue_date = models.DateTimeField(auto_now_add=True)
    due_date = models.DateTimeField()
    return_date = models.DateTimeField(blank=True, null=True)
    fine_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=10, choices=TRANSACTION_STATUS, default='active')
    
    def __str__(self):
        return f"{self.transaction_type} - {self.book.title} by {self.student.name}"