from rest_framework import serializers
from .models import Book, BookTransaction
from admissions.serializers import StudentSerializer

class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = '__all__'

class BookTransactionSerializer(serializers.ModelSerializer):
    book = BookSerializer(read_only=True)
    student = StudentSerializer(read_only=True)
    
    class Meta:
        model = BookTransaction
        fields = '__all__'