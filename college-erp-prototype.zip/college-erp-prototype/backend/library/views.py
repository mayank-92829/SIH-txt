from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from datetime import timedelta
from .models import Book, BookTransaction
from .serializers import BookSerializer, BookTransactionSerializer

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookTransactionViewSet(viewsets.ModelViewSet):
    queryset = BookTransaction.objects.all()
    serializer_class = BookTransactionSerializer
    
    @action(detail=True, methods=['post'])
    def issue_book(self, request, pk=None):
        book = Book.objects.get(pk=request.data.get('book_id'))
        student_id = request.data.get('student_id')
        
        if book.available_copies <= 0:
            return Response({'error': 'No copies available'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Create transaction
        transaction = BookTransaction.objects.create(
            book=book,
            student_id=student_id,
            transaction_type='issue',
            due_date=timezone.now() + timedelta(days=14)  # 2 weeks due date
        )
        
        # Update book availability
        book.available_copies -= 1
        if book.available_copies == 0:
            book.status = 'borrowed'
        book.save()
        
        return Response(BookTransactionSerializer(transaction).data)
    
    @action(detail=True, methods=['post'])
    def return_book(self, request, pk=None):
        transaction = self.get_object()
        
        if transaction.transaction_type != 'issue' or transaction.status == 'completed':
            return Response({'error': 'Invalid transaction'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Update transaction
        transaction.transaction_type = 'return'
        transaction.return_date = timezone.now()
        transaction.status = 'completed'
        
        # Calculate fine if overdue
        if transaction.return_date > transaction.due_date:
            days_overdue = (transaction.return_date - transaction.due_date).days
            transaction.fine_amount = days_overdue * 5  # $5 per day fine
        transaction.save()
        
        # Update book availability
        book = transaction.book
        book.available_copies += 1
        if book.available_copies > 0:
            book.status = 'available'
        book.save()
        
        return Response(BookTransactionSerializer(transaction).data)
    
    @action(detail=True, methods=['post'])
    def renew_book(self, request, pk=None):
        transaction = self.get_object()
        
        if transaction.transaction_type != 'issue' or transaction.status != 'active':
            return Response({'error': 'Cannot renew this book'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Extend due date by 2 weeks
        transaction.due_date = transaction.due_date + timedelta(days=14)
        transaction.save()
        
        return Response(BookTransactionSerializer(transaction).data)