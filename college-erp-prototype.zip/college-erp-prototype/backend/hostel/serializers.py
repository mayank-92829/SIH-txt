from rest_framework import serializers
from .models import Hostel, Room, HostelAllocation
from admissions.serializers import StudentSerializer

class HostelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hostel
        fields = '__all__'

class RoomSerializer(serializers.ModelSerializer):
    hostel = HostelSerializer(read_only=True)
    
    class Meta:
        model = Room
        fields = '__all__'

class HostelAllocationSerializer(serializers.ModelSerializer):
    student = StudentSerializer(read_only=True)
    room = RoomSerializer(read_only=True)
    
    class Meta:
        model = HostelAllocation
        fields = '__all__'