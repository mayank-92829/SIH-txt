from django.db import models
from admissions.models import Student

class Hostel(models.Model):
    name = models.CharField(max_length=100)
    total_rooms = models.IntegerField()
    available_rooms = models.IntegerField()
    amenities = models.TextField(blank=True)
    
    def __str__(self):
        return self.name

class Room(models.Model):
    ROOM_TYPES = (
        ('single', 'Single'),
        ('double', 'Double'),
        ('triple', 'Triple'),
        ('dorm', 'Dormitory'),
    )
    
    hostel = models.ForeignKey(Hostel, on_delete=models.CASCADE)
    room_number = models.CharField(max_length=10)
    room_type = models.CharField(max_length=10, choices=ROOM_TYPES)
    capacity = models.IntegerField()
    current_occupancy = models.IntegerField(default=0)
    is_available = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.hostel.name} - {self.room_number}"

class HostelAllocation(models.Model):
    ALLOCATION_STATUS = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('vacated', 'Vacated'),
    )
    
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    allocation_date = models.DateTimeField(auto_now_add=True)
    vacate_date = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=ALLOCATION_STATUS, default='pending')
    
    def __str__(self):
        return f"{self.student.name} - {self.room.room_number}"