from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Hostel, Room, HostelAllocation
from .serializers import HostelSerializer, RoomSerializer, HostelAllocationSerializer

class HostelViewSet(viewsets.ModelViewSet):
    queryset = Hostel.objects.all()
    serializer_class = HostelSerializer

class RoomViewSet(viewsets.ModelViewSet):
    queryset = Room.objects.all()
    serializer_class = RoomSerializer

class HostelAllocationViewSet(viewsets.ModelViewSet):
    queryset = HostelAllocation.objects.all()
    serializer_class = HostelAllocationSerializer
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        allocation = self.get_object()
        allocation.status = 'approved'
        
        # Update room occupancy
        room = allocation.room
        room.current_occupancy += 1
        if room.current_occupancy >= room.capacity:
            room.is_available = False
        
        room.save()
        allocation.save()
        
        return Response({'status': 'approved'})
    
    @action(detail=True, methods=['post'])
    def vacate(self, request, pk=None):
        allocation = self.get_object()
        allocation.status = 'vacated'
        
        # Update room occupancy
        room = allocation.room
        room.current_occupancy -= 1
        if room.current_occupancy < room.capacity:
            room.is_available = True
        
        room.save()
        allocation.save()
        
        return Response({'status': 'vacated'})