from django.core.management.base import BaseCommand
from admissions.models import Student
from fees.models import FeeType
from hostel.models import Hostel, Room
from library.models import Book

class Command(BaseCommand):
    help = 'Seed initial data for the application'

    def handle(self, *args, **options):
        # Create sample fee types
        fee_types = [
            {'name': 'Admission Fee', 'amount': 1000.00, 'description': 'One-time admission fee'},
            {'name': 'Tuition Fee', 'amount': 5000.00, 'description': 'Semester tuition fee'},
            {'name': 'Hostel Fee', 'amount': 2000.00, 'description': 'Monthly hostel charges'},
            {'name': 'Library Fee', 'amount': 500.00, 'description': 'Annual library membership'},
        ]
        
        for fee_data in fee_types:
            FeeType.objects.get_or_create(**fee_data)
            self.stdout.write(f"Created fee type: {fee_data['name']}")
        
        # Create sample hostels and rooms
        hostel, created = Hostel.objects.get_or_create(
            name='Main Hostel',
            defaults={'total_rooms': 10, 'available_rooms': 10, 'amenities': 'WiFi, Laundry, Mess'}
        )
        
        if created:
            self.stdout.write(f"Created hostel: {hostel.name}")
        
        for i in range(1, 6):
            room, created = Room.objects.get_or_create(
                hostel=hostel,
                room_number=f'101{i}',
                defaults={
                    'room_type': 'double',
                    'capacity': 2,
                    'current_occupancy': 0,
                    'is_available': True
                }
            )
            if created:
                self.stdout.write(f"Created room: {room.room_number}")
        
        # Create sample books
        books = [
            {'title': 'Introduction to Python', 'author': 'John Doe', 'isbn': '9781234567890', 'total_copies': 5, 'available_copies': 5},
            {'title': 'Web Development with Django', 'author': 'Jane Smith', 'isbn': '9780987654321', 'total_copies': 3, 'available_copies': 3},
            {'title': 'Database Systems', 'author': 'Robert Johnson', 'isbn': '9781122334455', 'total_copies': 4, 'available_copies': 4},
        ]
        
        for book_data in books:
            Book.objects.get_or_create(
                isbn=book_data['isbn'],
                defaults=book_data
            )
            self.stdout.write(f"Created book: {book_data['title']}")
        
        self.stdout.write(
            self.style.SUCCESS('Successfully seeded initial data!')
        )