from django.db import models

class DashboardMetrics(models.Model):
    total_students = models.IntegerField(default=0)
    total_pending_admissions = models.IntegerField(default=0)
    total_fee_collected = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    hostel_occupancy_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Metrics updated at {self.updated_at}"