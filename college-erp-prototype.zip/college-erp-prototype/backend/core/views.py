from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Count, Sum
from admissions.models import Student
from fees.models import FeePayment
from hostel.models import Hostel, Room, HostelAllocation
from library.models import Book, BookTransaction
from .models import DashboardMetrics

class DashboardViewSet(viewsets.ViewSet):
    
    @action(detail=False, methods=['get'])
    def metrics(self, request):
        # Calculate metrics
        total_students = Student.objects.count()
        total_pending_admissions = Student.objects.filter(status='applied').count()
        
        total_fee_collected = FeePayment.objects.filter(
            status='completed'
        ).aggregate(total=Sum('amount'))['total'] or 0
        
        total_rooms = Room.objects.count()
        occupied_rooms = HostelAllocation.objects.filter(
            status='approved'
        ).values('room').distinct().count()
        
        hostel_occupancy_rate = (occupied_rooms / total_rooms * 100) if total_rooms > 0 else 0
        
        # Library metrics
        total_books = Book.objects.count()
        borrowed_books = BookTransaction.objects.filter(
            transaction_type='issue', 
            status='active'
        ).count()
        
        # Create or update metrics
        metrics, created = DashboardMetrics.objects.get_or_create(pk=1)
        metrics.total_students = total_students
        metrics.total_pending_admissions = total_pending_admissions
        metrics.total_fee_collected = total_fee_collected
        metrics.hostel_occupancy_rate = hostel_occupancy_rate
        metrics.save()
        
        return Response({
            'total_students': total_students,
            'total_pending_admissions': total_pending_admissions,
            'total_fee_collected': float(total_fee_collected),
            'hostel_occupancy_rate': float(hostel_occupancy_rate),
            'total_books': total_books,
            'borrowed_books': borrowed_books,
        })