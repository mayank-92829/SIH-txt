from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import FeeTypeViewSet, FeePaymentViewSet

router = DefaultRouter()
router.register(r'types', FeeTypeViewSet)
router.register(r'payments', FeePaymentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]