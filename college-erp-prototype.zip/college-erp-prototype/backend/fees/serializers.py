from rest_framework import serializers
from .models import FeeType, FeePayment
from admissions.serializers import StudentSerializer

class FeeTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = FeeType
        fields = '__all__'

class FeePaymentSerializer(serializers.ModelSerializer):
    student = StudentSerializer(read_only=True)
    fee_type = FeeTypeSerializer(read_only=True)
    
    class Meta:
        model = FeePayment
        fields = '__all__'