from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import FeeType, FeePayment
from .serializers import FeeTypeSerializer, FeePaymentSerializer
from admissions.models import Student

class FeeTypeViewSet(viewsets.ModelViewSet):
    queryset = FeeType.objects.all()
    serializer_class = FeeTypeSerializer

class FeePaymentViewSet(viewsets.ModelViewSet):
    queryset = FeePayment.objects.all()
    serializer_class = FeePaymentSerializer
    
    @action(detail=True, methods=['post'])
    def simulate_payment(self, request, pk=None):
        payment = self.get_object()
        # Simulate payment processing
        payment.status = 'completed'
        payment.transaction_id = f"TXN{payment.id:06d}"
        payment.receipt_number = f"RCPT{payment.id:06d}"
        payment.save()
        
        # Update student fee status
        student = payment.student
        # This would be a field in the Student model in a real implementation
        
        return Response({
            'status': 'payment_completed',
            'transaction_id': payment.transaction_id,
            'receipt_number': payment.receipt_number
        })