from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Student, AdmissionDocument
from .serializers import StudentSerializer, AdmissionDocumentSerializer

class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        student = self.get_object()
        student.status = 'approved'
        # Generate roll number logic here
        student.roll_number = f"ROLL{student.id:04d}"
        student.save()
        return Response({'status': 'approved', 'roll_number': student.roll_number})
    
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        student = self.get_object()
        student.status = 'rejected'
        student.save()
        return Response({'status': 'rejected'})

class AdmissionDocumentViewSet(viewsets.ModelViewSet):
    queryset = AdmissionDocument.objects.all()
    serializer_class = AdmissionDocumentSerializer