from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StudentViewSet, AdmissionDocumentViewSet

router = DefaultRouter()
router.register(r'students', StudentViewSet)
router.register(r'documents', AdmissionDocumentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]