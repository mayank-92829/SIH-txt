import React, { useState, useEffect } from 'react';
import { getHostels, getRooms, createHostelAllocation, approveAllocation } from '../services/api';

const HostelAllocation = () => {
  const [hostels, setHostels] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [selectedHostel, setSelectedHostel] = useState('');
  const [selectedRoom, setSelectedRoom] = useState('');
  const [studentId, setStudentId] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchHostels();
  }, []);

  useEffect(() => {
    if (selectedHostel) {
      fetchRooms(selectedHostel);
    }
  }, [selectedHostel]);

  const fetchHostels = async () => {
    try {
      const hostelsData = await getHostels();
      setHostels(hostelsData);
    } catch (error) {
      console.error('Error fetching hostels:', error);
    }
  };

  const fetchRooms = async (hostelId) => {
    try {
      const roomsData = await getRooms();
      const filteredRooms = roomsData.filter(room => room.hostel === parseInt(hostelId) && room.is_available);
      setRooms(filteredRooms);
    } catch (error) {
      console.error('Error fetching rooms:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const allocation = await createHostelAllocation({
        student: parseInt(studentId),
        room: parseInt(selectedRoom)
      });
      
      // Approve allocation
      await approveAllocation(allocation.id);
      setMessage(`Hostel allocation successful! Room: ${allocation.room.room_number}`);
      
      setStudentId('');
      setSelectedHostel('');
      setSelectedRoom('');
    } catch (error) {
      setMessage('Error processing hostel allocation. Please try again.');
    }
  };

  return (
    <div>
      <h2>Hostel Allocation</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Student ID</label>
          <input
            type="number"
            className="form-control"
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Select Hostel</label>
          <select
            className="form-control"
            value={selectedHostel}
            onChange={(e) => setSelectedHostel(e.target.value)}
            required
          >
            <option value="">Select Hostel</option>
            {hostels.map(hostel => (
              <option key={hostel.id} value={hostel.id}>
                {hostel.name} ({hostel.available_rooms} rooms available)
              </option>
            ))}
          </select>
        </div>
        <div className="mb-3">
          <label className="form-label">Select Room</label>
          <select
            className="form-control"
            value={selectedRoom}
            onChange={(e) => setSelectedRoom(e.target.value)}
            required
            disabled={!selectedHostel}
          >
            <option value="">Select Room</option>
            {rooms.map(room => (
              <option key={room.id} value={room.id}>
                {room.room_number} ({room.room_type}, Capacity: {room.capacity})
              </option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-primary">Allocate Hostel</button>
      </form>
    </div>
  );
};

export default HostelAllocation;