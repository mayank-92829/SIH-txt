import React, { useState, useEffect } from 'react';
import { getFeeTypes, createFeePayment, simulatePayment } from '../services/api';

const FeePayment = () => {
  const [feeTypes, setFeeTypes] = useState([]);
  const [selectedFee, setSelectedFee] = useState('');
  const [studentId, setStudentId] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchFeeTypes();
  }, []);

  const fetchFeeTypes = async () => {
    try {
      const types = await getFeeTypes();
      setFeeTypes(types);
    } catch (error) {
      console.error('Error fetching fee types:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payment = await createFeePayment({
        student: parseInt(studentId),
        fee_type: parseInt(selectedFee)
      });
      
      // Simulate payment
      const result = await simulatePayment(payment.id);
      setMessage(`Payment successful! Transaction ID: ${result.transaction_id}, Receipt: ${result.receipt_number}`);
      
      setStudentId('');
      setSelectedFee('');
    } catch (error) {
      setMessage('Error processing payment. Please try again.');
    }
  };

  return (
    <div>
      <h2>Fee Payment</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Student ID</label>
          <input
            type="number"
            className="form-control"
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Fee Type</label>
          <select
            className="form-control"
            value={selectedFee}
            onChange={(e) => setSelectedFee(e.target.value)}
            required
          >
            <option value="">Select Fee Type</option>
            {feeTypes.map(fee => (
              <option key={fee.id} value={fee.id}>
                {fee.name} - ${fee.amount}
              </option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-primary">Pay Now</button>
      </form>
    </div>
  );
};

export default FeePayment;