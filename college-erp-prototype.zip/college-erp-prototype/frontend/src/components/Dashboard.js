import React from 'react';

const Dashboard = ({ metrics }) => {
  return (
    <div>
      <h2>College ERP Dashboard</h2>
      <div className="row">
        <div className="col-md-3">
          <div className="card text-white bg-primary mb-3">
            <div className="card-header">Total Students</div>
            <div className="card-body">
              <h5 className="card-title">{metrics.total_students || 0}</h5>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-white bg-warning mb-3">
            <div className="card-header">Pending Admissions</div>
            <div className="card-body">
              <h5 className="card-title">{metrics.total_pending_admissions || 0}</h5>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-white bg-success mb-3">
            <div className="card-header">Total Fees Collected</div>
            <div className="card-body">
              <h5 className="card-title">${metrics.total_fee_collected || 0}</h5>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-white bg-info mb-3">
            <div className="card-header">Hostel Occupancy</div>
            <div className="card-body">
              <h5 className="card-title">{metrics.hostel_occupancy_rate || 0}%</h5>
            </div>
          </div>
        </div>
      </div>
      
      <div className="row mt-4">
        <div className="col-md-12">
          <div className="card">
            <div className="card-header">
              <h5>System Overview</h5>
            </div>
            <div className="card-body">
              <p>This College ERP system manages student admissions, fee payments, and hostel allocations.</p>
              <p>Use the navigation menu to access different modules of the system.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;