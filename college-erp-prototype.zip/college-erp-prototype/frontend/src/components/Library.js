import React, { useState, useEffect } from 'react';
import { getBooks, issueBook, returnBook, renewBook, getBookTransactions } from '../services/api';

const Library = () => {
  const [books, setBooks] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [selectedBook, setSelectedBook] = useState('');
  const [studentId, setStudentId] = useState('');
  const [message, setMessage] = useState('');
  const [activeTab, setActiveTab] = useState('books');

  useEffect(() => {
    fetchBooks();
    fetchTransactions();
  }, []);

  const fetchBooks = async () => {
    try {
      const booksData = await getBooks();
      setBooks(booksData);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const fetchTransactions = async () => {
    try {
      const transactionsData = await getBookTransactions();
      setTransactions(transactionsData);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  };

  const handleIssueBook = async (e) => {
    e.preventDefault();
    try {
      await issueBook({
        book_id: parseInt(selectedBook),
        student_id: parseInt(studentId)
      });
      setMessage('Book issued successfully!');
      fetchBooks();
      fetchTransactions();
      setSelectedBook('');
      setStudentId('');
    } catch (error) {
      setMessage('Error issuing book. Please try again.');
    }
  };

  const handleReturnBook = async (transactionId) => {
    try {
      await returnBook(transactionId);
      setMessage('Book returned successfully!');
      fetchBooks();
      fetchTransactions();
    } catch (error) {
      setMessage('Error returning book. Please try again.');
    }
  };

  const handleRenewBook = async (transactionId) => {
    try {
      await renewBook(transactionId);
      setMessage('Book renewed successfully!');
      fetchTransactions();
    } catch (error) {
      setMessage('Error renewing book. Please try again.');
    }
  };

  return (
    <div>
      <h2>Library Management</h2>
      
      <ul className="nav nav-tabs">
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === 'books' ? 'active' : ''}`}
            onClick={() => setActiveTab('books')}
          >
            Books
          </button>
        </li>
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === 'issue' ? 'active' : ''}`}
            onClick={() => setActiveTab('issue')}
          >
            Issue Book
          </button>
        </li>
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === 'transactions' ? 'active' : ''}`}
            onClick={() => setActiveTab('transactions')}
          >
            Transactions
          </button>
        </li>
      </ul>

      <div className="tab-content mt-3">
        {message && <div className="alert alert-info">{message}</div>}
        
        {activeTab === 'books' && (
          <div>
            <h4>Book Inventory</h4>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>ISBN</th>
                  <th>Available Copies</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {books.map(book => (
                  <tr key={book.id}>
                    <td>{book.title}</td>
                    <td>{book.author}</td>
                    <td>{book.isbn}</td>
                    <td>{book.available_copies} / {book.total_copies}</td>
                    <td>
                      <span className={`badge ${book.status === 'available' ? 'bg-success' : 'bg-warning'}`}>
                        {book.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'issue' && (
          <div>
            <h4>Issue Book to Student</h4>
            <form onSubmit={handleIssueBook}>
              <div className="mb-3">
                <label className="form-label">Student ID</label>
                <input
                  type="number"
                  className="form-control"
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Select Book</label>
                <select
                  className="form-control"
                  value={selectedBook}
                  onChange={(e) => setSelectedBook(e.target.value)}
                  required
                >
                  <option value="">Select Book</option>
                  {books.filter(book => book.available_copies > 0).map(book => (
                    <option key={book.id} value={book.id}>
                      {book.title} by {book.author} (Available: {book.available_copies})
                    </option>
                  ))}
                </select>
              </div>
              <button type="submit" className="btn btn-primary">Issue Book</button>
            </form>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div>
            <h4>Book Transactions</h4>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Book</th>
                  <th>Student</th>
                  <th>Type</th>
                  <th>Issue Date</th>
                  <th>Due Date</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map(transaction => (
                  <tr key={transaction.id}>
                    <td>{transaction.book.title}</td>
                    <td>{transaction.student.name}</td>
                    <td>{transaction.transaction_type}</td>
                    <td>{new Date(transaction.issue_date).toLocaleDateString()}</td>
                    <td>{new Date(transaction.due_date).toLocaleDateString()}</td>
                    <td>
                      <span className={`badge ${transaction.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                        {transaction.status}
                      </span>
                    </td>
                    <td>
                      {transaction.transaction_type === 'issue' && transaction.status === 'active' && (
                        <>
                          <button 
                            className="btn btn-sm btn-success me-1"
                            onClick={() => handleRenewBook(transaction.id)}
                          >
                            Renew
                          </button>
                          <button 
                            className="btn btn-sm btn-primary"
                            onClick={() => handleReturnBook(transaction.id)}
                          >
                            Return
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Library;