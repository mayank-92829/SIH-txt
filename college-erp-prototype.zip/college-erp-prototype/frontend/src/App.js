import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import AdmissionForm from './components/AdmissionForm';
import FeePayment from './components/FeePayment';
import HostelAllocation from './components/HostelAllocation';
import Dashboard from './components/Dashboard';
import { getDashboardMetrics } from './services/api';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [metrics, setMetrics] = useState({});

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    try {
      const data = await getDashboardMetrics();
      setMetrics(data);
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  const renderView = () => {
    switch (currentView) {
      case 'admission':
        return <AdmissionForm />;
      case 'fee':
        return <FeePayment />;
      case 'hostel':
        return <HostelAllocation />;
      case 'dashboard':
      default:
        return <Dashboard metrics={metrics} />;
    }
  };

  return (
    <div className="App">
      <Navbar currentView={currentView} setCurrentView={setCurrentView} />
      <div className="container mt-4">
        {renderView()}
      </div>
    </div>
  );
}

export default App;