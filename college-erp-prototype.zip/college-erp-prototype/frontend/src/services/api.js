import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Admissions API
export const createStudent = (studentData) => 
  api.post('/admissions/students/', studentData).then(res => res.data);

export const getStudents = () => 
  api.get('/admissions/students/').then(res => res.data);

// Fees API
export const getFeeTypes = () => 
  api.get('/fees/types/').then(res => res.data);

export const createFeePayment = (paymentData) => 
  api.post('/fees/payments/', paymentData).then(res => res.data);

export const simulatePayment = (paymentId) => 
  api.post(`/fees/payments/${paymentId}/simulate_payment/`).then(res => res.data);

// Hostel API
export const getHostels = () => 
  api.get('/hostel/hostels/').then(res => res.data);

export const getRooms = () => 
  api.get('/hostel/rooms/').then(res => res.data);

export const createHostelAllocation = (allocationData) => 
  api.post('/hostel/allocations/', allocationData).then(res => res.data);

export const approveAllocation = (allocationId) => 
  api.post(`/hostel/allocations/${allocationId}/approve/`).then(res => res.data);

// Library API
export const getBooks = () => 
  api.get('/library/books/').then(res => res.data);

export const getBookTransactions = () => 
  api.get('/library/transactions/').then(res => res.data);

export const issueBook = (transactionData) => 
  api.post('/library/transactions/issue_book/', transactionData).then(res => res.data);

export const returnBook = (transactionId) => 
  api.post(`/library/transactions/${transactionId}/return_book/`).then(res => res.data);

export const renewBook = (transactionId) => 
  api.post(`/library/transactions/${transactionId}/renew_book/`).then(res => res.data);

// Dashboard API
export const getDashboardMetrics = () => 
  api.get('/core/dashboard/metrics/').then(res => res.data);

export default api;