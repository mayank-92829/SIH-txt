# College ERP Prototype

This is a prototype College ERP system built with Django REST Framework and React.

## Features

- Student Admissions Management
- Fee Payment Processing
- Hostel Allocation System
- Dashboard with Key Metrics

## Setup Instructions

1. Make sure you have Docker and Docker Compose installed on your system.

2. Clone this repository and navigate to the project directory.

3. Run the following command to start all services:

```bash
docker-compose up --build